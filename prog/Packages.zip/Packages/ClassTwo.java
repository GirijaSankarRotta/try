package sspack;

public class ClassTwo{
  public void methodClassTwo(){
    System.out.println("Hello there i am class Two");
    }
}